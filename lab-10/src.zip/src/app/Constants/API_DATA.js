export const GEO_URL = 'http://api.openweathermap.org/geo/1.0/'
export const API_KEY = '62e32e38f7d20ecfc394fcefa1ee3df8';

export const WEATHER_URL = 'http://api.openweathermap.org/data/2.5';